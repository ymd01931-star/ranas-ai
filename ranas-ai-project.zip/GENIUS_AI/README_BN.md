# RANA'S AI — Android starter project

**অ্যাপের নাম:** RANA'S AI  
**ব্যবহারকারীকে সম্বোধন:** Yousuf Sir  
**থিম:** Dark Premium  
**মোড:** Genius Mode, Autopsy Analysis, Killer Critic, Think 10x, Expose Mode

এটি একটি Android starter project, APK নয়। এতে Android chat UI, পাঁচটি বিশ্লেষণ মোড, বাংলা speech-to-text, Android Text-to-Speech এবং আলাদা Node.js backend আছে। ফোনের TTS ইঞ্জিনে বাংলা female voice থাকলে অ্যাপ সেটি বেছে নেওয়ার চেষ্টা করে; না থাকলে ফোনের default voice ব্যবহার করবে।

## ১. ফ্রি AI provider (Groq)

এই সংস্করণ OpenAI API নয়, Groq API ব্যবহার করার জন্য সাজানো। Groq-এর Free plan-এ সীমিত request/token quota থাকে; সীমা ছাড়ালে অপেক্ষা করতে হবে বা quota reset হওয়া পর্যন্ত ব্যবহার বন্ধ থাকবে। Paid Developer tier-এ যেতে payment method লাগে, তাই সেটি নির্বাচন করবে না।

1. https://console.groq.com/ এ Google account দিয়ে সাইন আপ করো।
2. https://console.groq.com/keys এ গিয়ে API key তৈরি করো।
3. API key কাউকে পাঠাবে না, GitHub-এ commit করবে না, Android অ্যাপের মধ্যে রাখবে না।
4. Backend host-এ secret/environment variable হিসেবে `GROQ_API_KEY` সেট করতে হবে।
5. চাইলে `GROQ_MODEL` হিসেবে `openai/gpt-oss-120b` (default) অথবা account-এ উপলব্ধ অন্য supported model ব্যবহার করা যাবে।

Groq Free plan-এর সীমা পরিবর্তন হতে পারে। বর্তমান model ও rate limit দেখো:  
- https://console.groq.com/docs/models  
- https://console.groq.com/docs/rate-limits

## ২. Android APK মোবাইল থেকে তৈরি

এই প্রজেক্টে `.github/workflows/android-apk.yml` দেওয়া আছে। এটি GitHub Actions দিয়ে cloud-এ debug APK build করে।

1. ZIP extract করে `GENIUS_AI` ফোল্ডারের ভেতরের সব ফাইল GitHub repository-তে upload করো। Repository-র নাম `ranas-ai` দিতে পারো।
2. Repository-র **Actions** tab খোলো। প্রথমবার workflow enable করতে বললে enable করো।
3. **Build RANA'S AI APK** workflow বেছে **Run workflow** চাপো।
4. Build সফল হলে workflow run-এর নিচে **Artifacts** থেকে `RANAS-AI-debug-apk` download করো।
5. ZIP extract করে `app-debug.apk` ফোনে install করো। Android-এ browser/files app-এর জন্য “Install unknown apps” অনুমতি দিতে হতে পারে।

GitHub Free-তে standard hosted runner-এর মাসিক Actions quota আছে; public repository-তে standard runner usage free। সীমা/নীতিমালা: https://docs.github.com/en/billing/concepts/product-billing/github-actions

## ৩. Backend চালু করা (AI chat-এর জন্য দরকার)

শুধু APK build করলেই AI chat চালু হবে না। Node.js backend-টি HTTPS hosting-এ deploy করতে হবে। Backend folder-এ Node.js 20+ প্রয়োজন:

```bash
npm install
npm start
```

Hosting service-এ environment variables:

```text
GROQ_API_KEY=তোমার_Groq_API_key
GROQ_MODEL=openai/gpt-oss-120b
APP_ACCESS_TOKEN=নিজের_লম্বা_এলোমেলো_গোপন_টোকেন
```

`APP_ACCESS_TOKEN` না দিলে endpoint-এ token authentication থাকবে না; public app-এর জন্য এটি সুপারিশ করা হয় না। Production hosting-এ HTTPS ব্যবহার করো। Health check: `/health`.

## ৪. অ্যাপে backend যুক্ত করা

অ্যাপ খুলে ⚙ চাপো। Backend URL-এ hosting-এর HTTPS base URL এবং App access token-এ একই `APP_ACCESS_TOKEN` বসিয়ে Save করো। API key অ্যাপে কখনো দেবে না।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- এই ZIP source project; এখানে compiled APK নেই। GitHub Actions-এ build সফল হলে APK পাওয়া যাবে।
- AI chat-এর জন্য Groq key ও backend hosting লাগবে। Groq Free tier quota-limited; নিরবচ্ছিন্ন বা unlimited service নিশ্চিত নয়।
- বাংলা female voice ফোনের Text-to-Speech engine-এ থাকলেই পাওয়া যাবে; সব ফোনে একই voice থাকবে না।
- এটি ব্যক্তিগত MVP; public release-এর আগে privacy policy, authentication, abuse protection ও আরও পরীক্ষা দরকার।
