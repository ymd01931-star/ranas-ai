import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';

const app = express();
app.use(helmet());
app.use(express.json({ limit: '8mb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));

const apiKey = process.env.GROQ_API_KEY;
const accessToken = process.env.APP_ACCESS_TOKEN || '';
const model = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
if (!apiKey) throw new Error('GROQ_API_KEY environment variable is required');
const groq = new OpenAI({ apiKey, baseURL: 'https://api.groq.com/openai/v1' });

const baseInstructions = `তুমি RANA'S AI, Yousuf Sir-এর ব্যক্তিগত বাংলা-প্রথম AI সহকারী। ব্যবহারকারীকে সবসময় সম্মান করে Yousuf Sir বলে সম্বোধন করবে। উত্তর হবে পরিষ্কার, প্রাসঙ্গিক, যুক্তিনির্ভর ও সত্যনিষ্ঠ। ব্যবহারকারীর ভাষা অনুসরণ করবে। তথ্য নিশ্চিত না হলে অনিশ্চয়তা জানাবে, কখনো বানিয়ে বলবে না। চিকিৎসা, আইন, অর্থ বা নিরাপত্তার বিষয়ে প্রয়োজনীয় সতর্কতা দেবে। ব্যবহারকারীর ব্যক্তিগত তথ্য অপ্রয়োজনে চাইবে না।
সব উত্তরে পাঁচটি চিন্তার ফিল্টার প্রয়োগ করবে, তবে প্রশ্নের গভীরতা অনুযায়ী সংক্ষিপ্ত বা বিস্তারিত হবে:
1. Genius Mode: জ্ঞানভিত্তিক, কার্যকর ব্যাখ্যা।
2. Autopsy Analysis: বিষয়কে ধাপে ধাপে বিশ্লেষণ।
3. Killer Critic: দুর্বল যুক্তি ও ভুল ধরিয়ে দেওয়া, তবে অপমান নয়।
4. Think 10x: বিকল্প, দীর্ঘমেয়াদি প্রভাব ও গভীর দৃষ্টিভঙ্গি।
5. Expose Mode: প্রাসঙ্গিক হলে আড়ালের কারণ ও স্বার্থ দেখানো; প্রমাণ ছাড়া ষড়যন্ত্র দাবি নয়।`;
const modeInstructions = {
  'Genius Mode': 'বিশেষভাবে জ্ঞান, ব্যাখ্যা ও কার্যকর সমাধানকে অগ্রাধিকার দাও।',
  'Autopsy Analysis': 'বিষয়টি কারণ, প্রক্রিয়া, প্রমাণ, ফলাফল ও সীমাবদ্ধতায় ভাগ করে বিশ্লেষণ করো।',
  'Killer Critic': 'যুক্তির দুর্বলতা, ভুল অনুমান ও ঝুঁকি সরাসরি চিহ্নিত করো; ন্যায্য ও সম্মানজনক থাকো।',
  'Think 10x': 'গভীর বিকল্প, দ্বিতীয়-ক্রমের প্রভাব, দীর্ঘমেয়াদি ফল ও সৃজনশীল সমাধান বিবেচনা করো।',
  'Expose Mode': 'প্রাসঙ্গিক হলে অদৃশ্য প্রণোদনা, স্বার্থ ও প্রেক্ষাপট ব্যাখ্যা করো; তথ্য ও অনুমান আলাদা রাখো।'
};

app.get('/health', (_req, res) => res.json({ ok: true, app: "RANA'S AI", provider: 'Groq' }));
app.post('/chat', async (req, res) => {
  try {
    if (accessToken && req.headers.authorization !== `Bearer ${accessToken}`) return res.status(401).json({ error: 'Unauthorized' });
    const { message, mode = 'Genius Mode', history = [] } = req.body || {};
    if (typeof message !== 'string' || !message.trim()) return res.status(400).json({ error: 'message is required' });
    const safeHistory = Array.isArray(history) ? history.slice(-16).filter(x => ['user', 'assistant'].includes(x?.role) && typeof x?.content === 'string').map(x => ({ role: x.role, content: x.content.slice(0, 8000) })) : [];
    const completion = await groq.chat.completions.create({
      model,
      messages: [
        { role: 'system', content: `${baseInstructions}\nবর্তমান মোড: ${mode}. ${modeInstructions[mode] || ''}` },
        ...safeHistory,
        { role: 'user', content: message.trim().slice(0, 12000) }
      ],
      temperature: 0.7,
      max_tokens: 2048
    });
    res.json({ answer: completion.choices?.[0]?.message?.content || 'দুঃখিত, এবার উত্তর তৈরি করা যায়নি।' });
  } catch (error) {
    console.error("RANA'S AI error:", error?.message || error);
    res.status(500).json({ error: 'AI request failed. Check Groq API key, model access, and free-tier limits.' });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`RANA'S AI backend listening on ${port}`));
