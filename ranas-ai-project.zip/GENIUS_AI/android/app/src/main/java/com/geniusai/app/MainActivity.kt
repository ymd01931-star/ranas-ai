package com.geniusai.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("genius_ai", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var mode: Spinner
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null
    private val history = JSONArray()
    private val modes = listOf("Genius Mode", "Autopsy Analysis", "Killer Critic", "Think 10x", "Expose Mode")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addBubble("RANA'S AI", "স্বাগতম, Yousuf Sir! আমি আপনার ব্যক্তিগত AI সহকারী। প্রশ্ন লিখুন, অথবা মাইক্রোফোনে কথা বলুন।", false)
        if (prefs.getString("backend", "").isNullOrBlank()) showSettings()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15, 23, 38)); setPadding(dp(14), dp(12), dp(14), dp(10)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "✦  RANA'S AI"; textSize = 23f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        val settings = Button(this).apply { text = "⚙"; setOnClickListener { showSettings() } }
        header.addView(settings)
        root.addView(header)
        status = TextView(this).apply { text = "তোমার ব্যক্তিগত বুদ্ধিমান সহকারী"; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(dp(2), 0, 0, dp(8)) }
        root.addView(status)
        mode = Spinner(this)
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        root.addView(mode)
        scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(Color.rgb(23, 34, 52)); clipToPadding = false; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10); bottomMargin = dp(10) })
        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "বাংলায় প্রশ্ন লিখো..."; textSize = 15f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.rgb(35, 49, 70)); minLines = 1; maxLines = 4 }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val mic = Button(this).apply { text = "🎙"; setOnClickListener { startVoiceInput() } }
        composer.addView(mic)
        val send = Button(this).apply { text = "➤"; setOnClickListener { sendMessage() } }
        composer.addView(send)
        root.addView(composer)
        setContentView(root)
    }

    private fun addBubble(label: String, body: String, mine: Boolean) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(9), dp(12), dp(9)); setBackgroundColor(if (mine) Color.rgb(44, 78, 119) else Color.rgb(36, 49, 68)) }
        val heading = TextView(this).apply { text = label; textSize = 11f; setTextColor(if (mine) Color.rgb(185, 215, 255) else Color.rgb(139, 190, 255)); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        val content = TextView(this).apply { text = body; textSize = 15f; setTextColor(Color.WHITE); setPadding(0, dp(4), 0, 0); setTextIsSelectable(true) }
        card.addView(heading); card.addView(content)
        val wrapper = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = if (mine) Gravity.END else Gravity.START; setPadding(0, dp(4), 0, dp(4)) }
        wrapper.addView(card, LinearLayout.LayoutParams(-1, -2).apply { width = (resources.displayMetrics.widthPixels * 0.86f).toInt() })
        messages.addView(wrapper)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        if (prefs.getString("backend", "").isNullOrBlank()) { showSettings(); return }
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        addBubble("তুমি", prompt, true)
        val priorHistory = JSONArray()
        for (i in 0 until history.length()) priorHistory.put(history.getJSONObject(i))
        history.put(JSONObject().put("role", "user").put("content", prompt))
        status.text = "ভাবছি..."
        val selectedMode = mode.selectedItem.toString()
        executor.execute {
            try {
                val backend = prefs.getString("backend", "")!!.trim().trimEnd('/') + "/chat"
                val token = prefs.getString("access_token", "") ?: ""
                val payload = JSONObject().put("message", prompt).put("mode", selectedMode).put("history", priorHistory)
                val conn = (URL(backend).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000; doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
                }
                conn.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw Exception("সার্ভার সমস্যা ($code): $responseText")
                val answer = JSONObject(responseText).optString("answer", "উত্তর পাওয়া যায়নি।")
                history.put(JSONObject().put("role", "assistant").put("content", answer))
                runOnUiThread { addBubble("RANA'S AI · $selectedMode", answer, false); status.text = "প্রস্তুত"; tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "genius-answer") }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { addBubble("সমস্যা", e.message ?: "সংযোগ করা যায়নি।", false); status.text = "সংযোগ পরীক্ষা করো" }
            }
        }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val endpoint = EditText(this).apply { hint = "Backend URL (যেমন https://your-server.com)"; setSingleLine(true); setText(prefs.getString("backend", "")) }
        val token = EditText(this).apply { hint = "App access token (ঐচ্ছিক)"; setSingleLine(true); setText(prefs.getString("access_token", "")) }
        box.addView(endpoint); box.addView(token)
        AlertDialog.Builder(this).setTitle("RANA'S AI সেটআপ").setMessage("AI চালাতে backend URL ও access token লাগবে। Groq API key অ্যাপে দেবে না।").setView(box)
            .setPositiveButton("সংরক্ষণ") { _, _ -> prefs.edit().putString("backend", endpoint.text.toString().trim()).putString("access_token", token.text.toString().trim()).apply(); status.text = "সেটিংস সংরক্ষিত" }
            .setNegativeButton("বন্ধ", null).show()
    }

    private fun startVoiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় বলো")
            }
            startActivityForResult(intent, 41)
        } catch (_: Exception) { Toast.makeText(this, "এই ফোনে ভয়েস ইনপুট পাওয়া যাচ্ছে না", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); input.setSelection(input.text.length) }
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale("bn", "BD")
            // Use a Bengali voice explicitly marked female when the phone provides one.
            val femaleBnVoice = tts?.voices?.firstOrNull {
                it.locale.language == "bn" && it.name.contains("female", ignoreCase = true)
            }
            if (femaleBnVoice != null) tts?.voice = femaleBnVoice
        }
    }
    override fun onDestroy() { tts?.shutdown(); executor.shutdown(); super.onDestroy() }
}
